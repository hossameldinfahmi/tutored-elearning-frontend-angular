export const environment = {
  production: true,
  baseUrl: "http://localhost:8000/api/",
  publishableKeyStripe:
    "pk_test_51N4C2MCnAe4mWFw2fLdkdIxaFOibNbuLjEBZRWOUmLEXyK68JmvmAr5aKhisWfsiaXaZTzz6z6uysSrNeAWwCsf1001cwsuWQq",
};
